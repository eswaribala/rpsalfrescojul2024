alfresco-rm-custom
==================

* Check out the code and start the server using the following maven command:

mvn integration-test -Prm,run

* Alfresco Share will be available at:

http://hostname:8080/share

* You will be able to create a RM site and select the custom compliance