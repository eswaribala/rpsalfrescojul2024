model.compliance.push(
{
   id: "{http://www.alfresco.org/model/myRecordsManagement/1.0}site",
   name: msg.get("mycustomcompliance")
});
