This folder (root in the AMP) gets mapped automagically in WEB-INF/licenses
in the war build