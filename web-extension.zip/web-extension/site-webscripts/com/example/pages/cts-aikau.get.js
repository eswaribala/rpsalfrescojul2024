model.jsonModel = {
    widgets: [
        {
            id: "SET_PAGE_TITLE",
            name: "alfresco/header/SetTitle",
            config: {
                title: "Cognizant AIKAU"
            }
        },
        {
            id: "DEMO_SIMPLE_MSG",
            name: "example/widgets/CognizantTextWidget"
        }
    ]
};      